// plan.types.ts

export interface IPricing {
  employee: number;
  snacking: number;
  teambuilding: number;
  wellBeing: number;
}
