export type LoginPayload = {
  accessToken: string;
  refreshToken: string;
};
