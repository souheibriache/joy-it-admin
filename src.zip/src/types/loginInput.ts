export type UserInput = {
  login: string;
  password: string;
};
