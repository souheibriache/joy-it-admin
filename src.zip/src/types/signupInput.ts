export type SignUpInput = {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  userName: string;
  confirmPassword: string;
};
