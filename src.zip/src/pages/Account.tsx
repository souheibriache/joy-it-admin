type Props = {};

const Account = ({}: Props) => {
  return <div>Account</div>;
};

export default Account;
