type Props = {};

const NotFound404 = ({}: Props) => {
  return <div>NotFound 404</div>;
};

export default NotFound404;
